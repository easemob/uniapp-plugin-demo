 zip -r ./libs.zip ./* -r 
